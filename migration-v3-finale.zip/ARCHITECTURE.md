# Solo Show — Technical Architecture Specification (V3)

## Document Purpose
This document is the **authoritative source of truth** for the Solo Show system architecture. It supersedes the V2 ARCHITECTURE.md and reflects a complete redesign of the finale system — replacing the consensus game with a physically embodied, four-phase sequence (group assembly, deliberation, ambassador ceremony, performer mix).

**When this document conflicts with code, this document is correct and the code should be updated.**

---

## Project Overview

### What This Is
An interactive live performance system where ~40 audience members help build songs in real time across a theatrical monologue. The show consists of three story/song-building cycles and a collaborative finale. The audience makes blind binary choices to layer musical elements while a Health Bar tracks the cumulative cost of their disagreement. Each layer costs more than the last (rising resistance), and if the Health Bar reaches zero, the song collapses — unreached layers are lost. Songs that survive all layers are narratively rejected by the performer anyway (self-sabotage). In the finale, the audience — abandoned by the performer — physically self-organizes into seven groups (one per layer type), deliberates on which fragment to carry forward, selects ambassadors, and ceremonially locks each layer into the final mix at a physical altar. The fragments, drawn from three different songs and emotional chapters, reveal through sound alone that they were always harmonically compatible. The performer returns to co-create the climax.

### Core Metaphor
> **"If I can build a song, I can build a life."**

The audience is framed as the performer's inner council — parts of the subconscious trying to cohere into a finished creative work. Disagreement is internal conflict. A collapsing song is the cumulative weight of internal division. The performer's rejection of a completed song is self-sabotage. The finale proves that integration was always possible — the council self-organizes, each part finds its role, and the fragments fit together without the ego directing them.

### Design Principles
1. **Story is uninterrupted.** Audience phones are used only during music-building and finale phases.
2. **Music is the metaphor.** No external props are required for meaning.
3. **Central timing, distributed choice.** The system runs on a master musical clock: audience controls *what* and *how*, not *when*.
4. **Legibility over complexity.** Binary choices, consistent visual cues, minimal UI.
5. **Safety constraints.** All musical actions are quantized and bounded so outputs remain coherent.
6. **Finale = embodiment + integration.** Audience physically self-organizes, deliberates, and ceremonially assembles the final song. The reveal arrives through the ear, not explanation.
7. **Projector tells the story, phone is the instrument.** Visual narrative lives on the projector; audience phones are input devices and personal audio preview tools.

---

## Terminology

| Term | Definition |
|------|------------|
| **Attempt** | One story/song-building cycle. The show has 3 attempts, each tied to a chapter. |
| **Chapter** | A thematic identity: Ambition (Song 1), Love (Song 2), Avoidance (Song 3). Chapters have consistent colors/icons throughout. |
| **Layer** | A single musical element within a song attempt. Each attempt has 7 layers. Each layer has a type (Melody, Drums, Pad, Bass, Harmony, FX1, FX2). |
| **Option** | One of 2 choices (A or B) within a layer. Binary choice. |
| **Lock-in** | When a layer's winning option is confirmed and becomes part of the song stack. |
| **Health Bar** | A visible gauge representing the song's vitality. Drains after each vote based on the losing vote proportion multiplied by a configurable layer multiplier. When it reaches zero, the song **collapses** — the current and all subsequent layers are lost. |
| **Drain** | The amount subtracted from the Health Bar after a vote. Equal to the losing side's proportion × 100 × drain factor × layer multiplier. |
| **Layer Multiplier** | A configurable per-layer scaling factor for drain. Increases with layer depth, representing the rising cost of creative commitment. Early layers are cheap; late layers are expensive. |
| **Collapse** | When the Health Bar reaches zero. The song "falls apart" — audio collapses via OSC-triggered effect, current and all unreached layers are lost. Fragments from reached layers survive for the finale. |
| **Blind Vote** | The song-building voting mechanic. Audience votes without seeing live split feedback. Results are revealed after the window closes. |
| **Reveal** | The post-vote moment when the A/B split is shown, the health bar drains, and the winning option locks in. |
| **Song Rejection** | The performer's narrative act of rejecting a **completed** song (one that survived all layers without collapsing). Triggered manually via controller; accompanied by an OSC-triggered audio effect. Only applies when the song completes — collapsed songs are already dead. |
| **Fragment** | A winning option from a reached layer during song-building, available in the finale. Only winners from layers that were actually voted on survive. |
| **Locked Fragment** | A fragment visible in the pre-game "elegy" display but not available during gameplay. Includes: losing options from voted layers AND both options from unreached layers (due to collapse). Represents "what could have been." |
| **Group Assembly** | The first active finale phase. Audience members self-select into one of 7 layer-type groups by choosing a role on their phone, then physically finding others who chose the same role. Timer-based; undecided members are randomly assigned when the timer expires. |
| **Deliberation** | The second active finale phase. Each group privately previews available fragments for their layer type on their phones and votes for which fragment to carry into the final song. Timer-based; majority wins when the timer expires. |
| **Audio Preview** | In-browser playback of pre-rendered fragment audio files during deliberation. Each audience member controls playback independently on their own phone. |
| **Ambassador** | One volunteer from each group who carries the group's chosen fragment to the altar during the ceremony. Selected by volunteering; random selection if multiple volunteers; layer forfeited if no volunteer. |
| **Ceremony** | The third active finale phase. Ambassadors are called one at a time in a fixed configurable order. Each approaches the altar and locks their group's fragment into the final mix by placing their phone face-down on the altar surface. |
| **Altar** | A physical surface on stage. Requires no electronics — the ambassador's phone detects the face-down placement via the accelerometer. The altar's power is accumulated from staging and narrative, not technology. |
| **Altar Lock-in** | The gesture that activates a fragment: the ambassador places their phone face-down on the altar and holds it still for ~2 seconds. Detected via Device Orientation / Accelerometer API. Triggers immediate audio activation (quantized to next bar boundary). |
| **NPC** | A system-controlled narrative voice displayed on audience phones during the finale. Reacts to key events (performer abandonment, group formation, ceremony moments). Terminal-style typeface. Event-driven, not auto-triggered on a per-round basis. |
| **Performer Mix** | The final phase of the finale. The performer live-mixes fragments using a visual mixing surface, with changes quantized to loop boundaries. Initial state is pre-loaded from the ceremony results. |
| **Pending Changes** | Fragment activations/deactivations queued by the performer that fire simultaneously at the next loop boundary. |
| **Loop Boundary** | The downbeat of each 8-bar loop cycle. All audio changes are quantized to these boundaries. |
| **Layer Identity** | Consistent color + symbol for each layer type, used across all 3 attempts. |
| **Chapter Identity** | Consistent color + icon for each chapter, used across all UIs. |

---

## System Components

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENTS                                  │
├─────────────────┬─────────────────┬─────────────────────────────┤
│  /audience      │  /projector     │  /controller                │
│  (~40 users)    │  (1 display)    │  (performer/operator)       │
└────────┬────────┴────────┬────────┴──────────────┬──────────────┘
         │                 │                       │
         └─────────────────┼───────────────────────┘
                           │ WebSocket (Socket.IO)
                           ▼
┌──────────────────────────────────────────────────────────────────┐
│                    SERVER (Node.js)                               │
│  ┌────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │
│  │    Next.js     │  │    Socket.IO     │  │   Persistence    │  │
│  │  (page routes) │  │    (real-time)   │  │    (SQLite)      │  │
│  └────────────────┘  └────────┬─────────┘  └──────────────────┘  │
│                               │                                   │
│                      ┌────────▼─────────┐                        │
│                      │    Conductor     │  ← Pure state machine  │
│                      │   (show logic)   │                        │
│                      └──────────────────┘                        │
│  ┌──────────────────┐  ┌──────────────────┐                      │
│  │  Timing Engine   │  │   OSC Bridge     │  ← Ableton Live      │
│  │ (quantized       │◄─┤  (bidirectional) │    integration       │
│  │  advance)        │  └────────┬─────────┘                      │
│  └──────────────────┘          │                                  │
└──────────────────────────────────┼──────────────────────────────┘
                                   │ OSC over UDP (localhost)
                                   ▼
                    ┌──────────────────────────────┐
                    │   Ableton Live + AbletonOSC    │
                    │   (musical timing, audio)     │
                    └──────────────────────────────┘
```

### Architecture: Next.js with Custom Server

Unchanged from V1. Single process serves Next.js pages and real-time show logic via Socket.IO.

### Deployment Model

Unchanged from V1. Cloud-hosted server with local Ableton bridge.

### Static Audio Preview Files

Pre-rendered audio files (mp3/ogg) for each of the 42 fragment clips, exported from Ableton and served statically by the Next.js server. Used during the deliberation phase for in-browser playback on audience phones.

**File naming convention:** `preview-{songIndex}-{layerIndex}-{option}.mp3` (e.g., `preview-0-2-A.mp3`)

**Serving:** Static files from `public/audio/previews/` directory, served via Next.js static file handling.

**Production step:** Render each Ableton clip as a short audio file (4–8 bars recommended; full 8-bar loop acceptable). Export at 128kbps mp3 for minimal file size while maintaining adequate quality for phone speakers in a noisy room.

---

## Client Routes (Next.js App Router)

### `/audience` — Audience Member UI

**Join flow:** Unchanged from V1.

**Story phases (phones down):** Screen goes dark/minimal ("listen" state).

**Song-building phases:**
- Two large tappable cards: Option A (left) and Option B (right), styled with layer color + symbol
- **Blind vote**: no live feedback on vote split during the voting window
- After vote closes → **Reveal sequence**:
  1. Both options shown side by side, no result (tension beat)
  2. Split revealed: winning option grows, losing option shrinks proportionally
  3. Health Bar animates its drain (shadow region depletes)
  4. Winning option's audio locks into the mix
- Health Bar always visible (top of screen), showing cumulative song vitality
- Layer progress indicator showing completed layers and upcoming layers
- Personal vote history dot on each completed layer (subtle indicator of which side you voted for)

**Finale — Elegy moment (optional pre-assembly beat):**
- Full grid of all fragments from all three songs, organized by role
- Winners glowing, losers/locked fragments visually cracked or dimmed
- NPC text narrates: "This is what we have left. This is what we lost."
- Duration: ~10–15 seconds, purely observational, no interaction

**Finale — Group Assembly:**
- 7 tappable cards, one per layer type, each showing: layer symbol, layer color, configurable label (e.g., "The Heartbeat", "The Ground")
- Live group size count displayed on each card (updates in real time as others join)
- Timer visible at top of screen (configurable duration, e.g., 60 seconds)
- Tap a card to join that group; tap a different card to switch (free choice, no constraints)
- NPC text may appear to frame the moment ("Choose your role. Find each other.")
- When timer expires: any undecided audience members are randomly assigned to a group by the server
- After assignment: screen transitions to show "You are [Layer Label]" with the group's symbol, color, and member count, plus instruction to physically find others with the same role
- Groups with 0 members are marked empty — that layer type will be skipped in the ceremony

**Finale — Deliberation:**
- Header: group identity (layer symbol + color + label + member count)
- Available fragments for this layer type displayed as tappable cards (1–3 cards, one per song that has an available fragment for this layer type)
- Each fragment card shows: chapter color, emotional tagline from song-building, play/pause button for audio preview
- **Audio preview**: tap play to hear the fragment on the phone speaker; tap again to pause; only one fragment plays at a time per phone (switching auto-pauses the previous)
- Vote button on each card: tap to cast vote for this fragment; can change vote freely during the timer
- Live vote tally visible to group members (within-group transparency, unlike the blind song-building vote)
- Timer visible at top (configurable duration, e.g., 120 seconds)
- When timer expires: the fragment with the most votes wins (simple majority); ties broken randomly
- After vote resolves: screen shows the chosen fragment with celebration animation
- **Ambassador volunteering**: after the fragment is chosen, a prompt appears: "Will you carry this forward?" with Accept/Decline buttons. Timer for volunteering (e.g., 15 seconds). If multiple volunteer, one is selected randomly. If none volunteer, the layer is forfeited — NPC acknowledges the loss.
- After ambassador is selected: ambassador's phone shows a distinct "Ambassador" state; other group members see who was chosen

**Finale — Ceremony:**
- **Non-ambassadors**: passive viewing state. Screen shows the ceremony progress — which layers have been locked, which ambassador is currently called, the layer order
- **Ambassador (before being called)**: waiting state with their layer identity prominent. "Wait for your name."
- **Ambassador (when called)**: phone enters altar-ready mode. Screen shows instruction: "Approach the altar. Place your phone face-down." Device Orientation API begins listening for face-down + still detection.
- **Altar lock-in detection**: phone uses `DeviceOrientationEvent` to detect when the device is face-down (gravity vector pointing upward through the screen, i.e., beta ≈ ±180° or gamma ≈ ±180° depending on orientation). Must remain in face-down position and substantially still (accelerometer delta < threshold) for ~2 seconds. On detection: sends lock-in event to server, phone vibrates once (if Vibration API available), screen illuminates with confirmation glow in the layer's color.
- **After lock-in**: ambassador picks up phone, sees confirmation. Audio for this fragment fades into the room mix (quantized to next bar boundary, using existing fade-in mechanic). Ceremony advances to next layer.
- **Forfeited layers** (no ambassador): skipped in the ceremony order with brief NPC acknowledgment

**Finale — Performer Mix phase:**
- **TBD** — Options under consideration: phones go dark, minimal ambient visualization, or endorsement tap surface. See Open Questions.

### `/projector` — Public Display

**Story phases:** Dark or minimal atmospheric display.

**Song-building phases:**
- Top: Song attempt title + chapter color/icon
- Center: Current layer card — layer symbol + label, Option A vs Option B
- Health Bar: large, prominent, visible to whole room
- Reveal animation: vote split visualization, health bar drain
- Stack history: icons of chosen layers so far

**Finale — Elegy:**
- Full fragment grid with winners glowing, losers/locked dimmed
- NPC text displayed prominently

**Finale — Group Assembly:**
- Large visualization of the 7 groups forming in real time
- Each group shown with layer symbol, color, and growing member count
- Animated: members flowing into groups as people choose on their phones
- Timer displayed prominently
- NPC text when relevant

**Finale — Deliberation:**
- Overview of all 7 groups and their deliberation status
- Per-group: which fragment is currently leading (vote counts visible on projector, unlike phones which show only within-group)
- Groups that have reached majority shown with a "decided" visual state
- Ambassador volunteering status visible as it happens
- Timer displayed prominently

**Finale — Ceremony:**
- Central focus: the current ambassador being called
- Layer identity (symbol + color + label) displayed large
- The chosen fragment's chapter color and emotional tagline
- Lock-in celebration animation when altar detects the phone
- Assembled layers stack visualization — each locked layer glows, building the visual representation of the final song
- Forfeited layers shown as dark/absent gaps in the stack

**Finale — Performer Mix:**
- Mirror of the performer's mixing surface (simplified/beautified)
- 7 rows showing active fragment per layer, chapter color
- Pending changes visible (pulsing, about to land)
- Loop position indicator
- Visual energy/density increases as mix builds
- When performer adds live performance layer (vocal, synth), new visual element appears that signals transcendence

### `/controller` — Performer/Operator Interface

**Access:** Secret route + passcode.

**Core Controls:**

| Category | Controls |
|----------|----------|
| **Show Phase** | Start Show, Stop Show, Advance Phase, Jump to Phase (dropdown) |
| **Song-Building** | Open Vote, Close Vote, Force Option A/B, Extend Timer, Rerun Vote |
| **Health Bar** | Adjust drain factor per attempt, Adjust layer multipliers, View current health, Override health value, Force Collapse |
| **Song Rejection** | Trigger rejection effect (OSC command to Ableton) — only for completed songs |
| **Audio** | Transport Play/Stop, Hard Mute/Panic, Reset Utilities (all gains to 0 dB), Per-layer force on/off |
| **Finale — Assembly** | View group sizes in real time, Extend/shorten timer, Force-assign user to group, Force end assembly early |
| **Finale — Deliberation** | View per-group vote distributions, Extend/shorten timer, Force fragment selection for a group, Force end deliberation early |
| **Finale — Ceremony** | View ambassador status per group, Call next ambassador (auto-advances in fixed order, but can skip/reorder), Force lock-in for a layer, Mark layer as forfeited, Fire NPC lines manually |
| **Finale — Performer Mix** | 7×6 mixing grid (7 layers × 6 fragments: 3 songs × 2 options), Queue/dequeue fragment changes, Mute/unmute layers, Snapshot presets, Loop position display |
| **NPC** | Bank of pre-written NPC lines (organized by phase), Free-text input for improvised lines, Fire button |
| **Live Performance** | Toggle live input tracks (vocal, synth, etc.) |
| **Emergency** | Pause/Resume show, Export/Import state as JSON, Force reconnect all clients, Reset to lobby |

**Metrics/Telemetry:**
- Connected clients count
- Vote counts A vs B, time remaining
- Health bar status per attempt
- Assembly: group sizes per layer type, timer remaining, undecided count
- Deliberation: per-group fragment votes, timer remaining, ambassador volunteer status
- Ceremony: current layer, ambassador status, locked layers, forfeited layers
- Performer mix: active layers, pending changes, loop position
- System health: WebSocket status, Ableton OSC status, error log tail

---

## Show Phase State Machine

```
lobby → opener → attempt_story → attempt_build → attempt_resolve (if completed) →
                                       ↓ (if collapsed)
                 attempt_story → attempt_build → attempt_resolve (if completed) →
                                       ↓ (if collapsed)
                 attempt_story → attempt_build → attempt_resolve (if completed) →
                                       ↓ (if collapsed)
                 finale_elegy → finale_assembly → finale_deliberation → finale_ceremony → finale_performer_mix → ended
```

### Phase Details

```typescript
type ShowPhase =
  | 'lobby'                    // Audience joining, scanning QR codes
  | 'opener'                   // Performer monologue (phones dark)
  | 'attempt_story'            // Story phase for current attempt (phones dark)
  | 'attempt_build'            // Song-building phase for current attempt (phones active)
  | 'attempt_resolve'          // Song completed; performer rejects it (phones dim/watch)
  | 'finale_elegy'             // Audience sees full fragment wreckage (phones passive)
  | 'finale_assembly'          // Audience self-selects into 7 layer-type groups (phones active)
  | 'finale_deliberation'      // Groups preview fragments, vote, select ambassadors (phones active)
  | 'finale_ceremony'          // Ambassadors lock fragments at the altar (phones active for ambassadors)
  | 'finale_performer_mix'     // Performer live-mixes and escalates (phones TBD)
  | 'ended';
```

**Note:** `attempt_story`, `attempt_build`, and `attempt_resolve` are parameterized by `currentAttemptIndex` (0, 1, 2). `attempt_resolve` is only entered when a song completes (health bar > 0 after all layers). Collapsed songs skip `attempt_resolve`.

### Transitions

| From | To | Trigger | Notes |
|------|----|---------|-------|
| `lobby` | `opener` | Manual | |
| `opener` | `attempt_story` | Manual | Sets currentAttemptIndex = 0 |
| `attempt_story` | `attempt_build` | Manual | Activates voting UI |
| `attempt_build` | `attempt_resolve` | **Auto** | When all layers voted on AND health bar > 0 |
| `attempt_build` | `attempt_story` | **Auto** | When health bar reaches 0 (collapse); increments attempt index |
| `attempt_build` (attempt 2) | `finale_elegy` | **Auto** on collapse, or Manual after rejection | Song 3 → finale regardless of outcome |
| `attempt_resolve` | `attempt_story` | Manual | Performer triggers rejection + advance; increments attempt index |
| `attempt_resolve` (attempt 2) | `finale_elegy` | Manual | After Song 3 rejection |
| `finale_elegy` | `finale_assembly` | Manual or Auto (after timer) | NPC rallies the audience |
| `finale_assembly` | `finale_deliberation` | **Auto** | When assembly timer expires (undecided randomly assigned first) |
| `finale_deliberation` | `finale_ceremony` | **Auto** | When deliberation timer expires (majority locked, ambassadors resolved) |
| `finale_ceremony` | `finale_performer_mix` | Manual or **Auto** | When all non-forfeited layers locked in, or performer triggers transition |
| `finale_performer_mix` | `ended` | Manual | |

---

## Song-Building Phase — Detailed Mechanics

### Layer Structure

Each attempt has exactly **7 layers**, one per layer type. The layer ordering is **staggered across songs** to ensure that across all three songs, every layer type is voted on early at least once. This creates both musical differentiation (each song builds from a different starting point) and guarantees diverse fragment availability regardless of health bar state.

```typescript
interface LayerConfig {
  index: number;              // 0-indexed position in this attempt's build order
  type: LayerType;            // Which musical role
  optionA: AudioReference;    // Ableton clip/track reference
  optionB: AudioReference;    // Ableton clip/track reference
  labelA: string;             // Short emotional tagline for A (e.g., "the ground that held")
  labelB: string;             // Short emotional tagline for B (e.g., "the ground that crumbled")
}

type LayerType =
  | 'melody'    // Defines chords, melodic hooks — harmonically specific
  | 'drums'     // Rhythmic patterns — harmonically neutral
  | 'pad'       // Sustained warmth, texture — harmonically compatible
  | 'bass'      // Low-end foundation — semi-harmonic (roots + fifths)
  | 'harmony'   // Arpeggios, counter-melodies — harmonically compatible
  | 'fx1'       // Risers, sweeps, transitions — harmonically neutral
  | 'fx2';      // Textures, atmospheres, foley — harmonically neutral
```

### Staggered Layer Ordering

| Position | Song 1 (Ambition) | Song 2 (Love) | Song 3 (Avoidance) |
|----------|-------------------|---------------|---------------------|
| Layer 0 | Bass | Melody | Pad |
| Layer 1 | Drums | Harmony | FX1 |
| Layer 2 | Pad | Bass | Drums |
| Layer 3 | Melody | Drums | Bass |
| Layer 4 | Harmony | Pad | Melody |
| Layer 5 | FX1 | FX1 | Harmony |
| Layer 6 | FX2 | FX2 | FX2 |

This ensures: every layer type appears in the first 3 layers of at least one song. FX layers are pushed toward the end as they are less structurally essential.

### Layer Phase Transitions (within `attempt_build`)

```
locked → auditioning → voting → revealing → locked_in
                                    │
                                    ▼ (if health bar reaches 0)
                                collapsed (attempt ends)
```

```typescript
type LayerPhase =
  | 'locked'        // Not yet reached; displayed as upcoming
  | 'auditioning'   // Playing A and B previews for the room
  | 'voting'        // Blind vote window open
  | 'revealing'     // Vote closed, reveal sequence playing
  | 'locked_in'     // Winner confirmed, added to song stack
  | 'collapsed';    // Health bar hit zero at this layer; attempt ends
```

### Blind Vote Mechanic

The vote window is a configurable duration (default: 10–15 seconds). During this window:
- Audience sees Option A and Option B as large tappable cards
- Each user taps once to vote; vote is final (no changing during blind vote)
- **No live feedback** on vote distribution. The audience cannot see which option is leading.
- This preserves authentic expression: you vote your preference, not the crowd's momentum

When the vote window closes, the **Reveal Sequence** plays (~5s total, matching `revealSequenceDurationMs`). The conductor pauses at `revealing` phase until `ADVANCE_FROM_REVEAL` fires from the timing engine after this duration.

1. **Tension beat** (~0.9s): both options displayed equal size, muted, no result
2. **Split reveal** (~2s): winning option grows (flex proportional to consensus), losing option shrinks + dims
3. **Health bar drain** (~1.5s): drain shadow appears briefly then animates actual depletion; projector shows exact vote counts, audience sees only the visual split
4. **Lock-in** (~0.5s): winning option gets glow accent
5. **Advance**: `ADVANCE_FROM_REVEAL` fires → `lockInLayer()` or `collapseAttempt()`; next layer begins auditioning

### Health Bar

The Health Bar starts at 100 for each attempt and drains after every vote. Each layer costs more than the last via a configurable layer multiplier, representing the rising cost of creative commitment.

```typescript
interface HealthBarState {
  current: number;            // 0.0 to 100.0
  drainFactor: number;        // Base multiplier for drain amount (configurable per attempt)
  layerMultipliers: number[]; // Per-layer scaling factors (configurable, length = layersPerAttempt)
  history: HealthBarDrain[];  // Record of each drain event
}

interface HealthBarDrain {
  layerIndex: number;
  losingProportion: number;   // 0.0 to 0.5 (the minority side's share)
  layerMultiplier: number;    // The multiplier for this specific layer
  drainAmount: number;        // losingProportion * 100 * drainFactor * layerMultiplier
  healthAfter: number;        // Health bar value after this drain
}
```

**Drain calculation:**
```
losingProportion = min(votesA, votesB) / totalVotes
drainAmount = losingProportion * 100 * drainFactor * layerMultiplier[layerIndex]
newHealth = max(0, currentHealth - drainAmount)
```

**Default layer multipliers:** `[0.5, 0.6, 0.8, 1.0, 1.3, 1.6, 2.0]`

Early layers are cheap — even significant disagreement barely scratches the health bar. Late layers are expensive — even moderate disagreement takes a large chunk. This guarantees that the first 2–3 layers almost always survive while making collapse increasingly likely in later layers.

**What the audience sees:** The drain amount is visually proportional to the damage. A large drain gets a dramatic animation; a small drain is barely noticeable. The health bar color shifts from healthy (green/bright) to critical (red/dark) as it decreases.

**Tuning guide** (with drainFactor = 0.5, default multipliers):
- Room averaging 70/30 splits → collapses around layer 5–6
- Room averaging 80/20 splits → survives to layer 6–7 (may complete)
- Room averaging 55/45 splits → collapses around layer 3–4

**Per-attempt tuning:** Both `drainFactor` and `layerMultipliers` can vary per song. Song 1 could be more forgiving (lower factor or gentler multiplier curve) as the audience learns. Song 3 could be harsher for dramatic tension.

### Collapse Behavior

When the health bar reaches zero after a vote's drain is applied:
1. The current layer enters `collapsed` phase — the vote's winner is still determined but the layer does NOT lock in
2. **Audio**: Collapse effect triggers via OSC (return track effects — distortion, filter sweep, reverb tail)
3. **Visual**: Health bar shatters/empties on projector; phone UI shows collapse state
4. **System**: All remaining layers for this attempt are marked `unreached`
5. **Data**: Locked-in layers from earlier in this attempt are preserved as available finale fragments. The collapsed layer and all unreached layers are lost (both options visible but locked in finale elegy).
6. After collapse animation duration, system transitions to next phase (auto-advance to `attempt_story` for Songs 1–2; manual advance to `finale_elegy` for Song 3)

### Song Completion & Rejection

If a song survives all 7 layers (health bar > 0 after final vote):
1. The complete song plays for 15–20 seconds — the audience hears their creation
2. The performer **narratively rejects** the song (self-sabotage)
3. A **rejection effect** is triggered via OSC (TBD: filter sweep, distortion, abrupt cut — configurable, distinct from collapse effect)
4. The system transitions to `attempt_resolve` phase
5. The performer advances to the next `attempt_story` when ready

**Two distinct endings:** Collapse is the cumulative weight of division killing the song — the audience's failure. Rejection is the performer killing a healthy song — the performer's failure. Both should have distinct audio and visual treatments so the audience can feel the difference.

### Song Stack & Fragment Generation

After each attempt, the system records:

```typescript
interface AttemptResult {
  attemptIndex: number;                // 0, 1, 2
  chapter: Chapter;                    // 'ambition' | 'love' | 'avoidance'
  layers: LayerResult[];               // Length 7 (includes unreached layers)
  completed: boolean;                  // True if all layers reached and passed
  collapsedAtLayer: number | null;     // Layer index where collapse occurred, or null
  healthBarFinal: number;              // Final health bar value
  healthBarHistory: HealthBarDrain[];  // Drain record for each voted layer
}

interface LayerResult {
  layerIndex: number;
  type: LayerType;
  status: 'locked_in' | 'unreached';  // unreached = never got to vote (collapse happened earlier)
  chosenOption: 'A' | 'B' | null;     // null if unreached
  consensus: number | null;            // null if unreached
  drainAmount: number | null;          // null if unreached
}
```

**Fragment availability for finale:**
- `locked_in` layers: the **winning** option becomes an available fragment in the finale
- `locked_in` layers: the **losing** option is visible in the elegy display but NOT available during gameplay
- `unreached` layers (due to collapse): **both** options are visible in the elegy display but NOT available during gameplay — these represent "what could have been"
- The performer's mixing surface has access to **all fragments** regardless of availability (both winners and losers from reached layers, plus both options from unreached layers)

**Fragment count depends on show performance:**
- Best case (all 3 songs complete): 21 available fragments (7 × 3)
- Typical case (songs collapse at layers 4–6): 12–18 available fragments
- Worst case (very early collapses): as few as 6–9 available fragments
- The staggered layer ordering guarantees that every layer type has at least one available fragment if each song reaches at least 2–3 layers

---

## Finale System — Detailed Mechanics

### Overview

The finale has five sub-phases:
1. **Elegy** — audience observes the wreckage of all three songs (optional brief beat)
2. **Assembly** — audience self-selects into 7 layer-type groups and physically regroups
3. **Deliberation** — groups preview audio, vote on fragments, and select ambassadors
4. **Ceremony** — ambassadors lock fragments into the final mix at the altar
5. **Performer Mix** — performer returns to live-mix the escalation and climax

### Narrative Setup

After Song 3's resolution (collapse or rejection), the performer "abandons" the stage — stepping back, giving up, unable to finish anything. Lights shift to red. Every audience member's phone receives an NPC message in terminal-style typeface. The NPC represents the "inner council" gaining consciousness and refusing to let the creator give up: *"He's gone. We need to do this ourselves."*

This frames the finale as a mutiny — the audience acting without the performer, each part of the mind finding its role, proving integration was always possible.

### Phase 1: Finale Elegy

An optional 10–15 second observational moment. Phones show the full grid of all fragments from all three songs:
- Winning fragments glow with their chapter color
- Losing fragments are cracked, dimmed, desaturated
- Organized by role (7 rows)
- NPC narrates: acknowledges what survived and what was lost
- No interaction — pure narrative beat
- Transitions to assembly when NPC rallies the audience (manual or auto-timed)

### Phase 2: Group Assembly

The audience physically self-organizes into seven groups — one per layer type.

**Phone UI:** Seven tappable cards, each displaying the layer's symbol, color, and configurable label (from `default-show.json`). Live group size counts update in real time as people choose. No constraints on group size — any group can be empty or hold all 40 people.

**Timer:** Configurable duration (default: 60 seconds). Displayed prominently on phones and projector. When the timer expires:
1. Any audience member who has not selected a group is **randomly assigned** to one of the 7 groups by the server
2. Groups with 0 members are marked as **empty** — that layer type will be skipped in the ceremony and will not have a fragment in the initial mix
3. The system transitions to the deliberation phase

**Physical movement:** After groups are assigned (timer expiry), the phone screen shows "You are [Layer Label]" with the group's identity. The audience is expected to physically move to find others with the same role. The chaos of reorganization is intentional — it mirrors the script's theme of internal parts finding each other. The system does NOT wait for physical assembly to complete; the deliberation timer begins after a brief grace period (configurable, e.g., 10–15 seconds).

**Projector:** Shows the groups forming in real time — animated member counts, layer symbols growing/pulsing as people join. Timer prominent.

### Phase 3: Deliberation

Each group privately deliberates on which fragment to carry into the final song.

**Phone UI per group:** Shows only the available fragments for this group's layer type (1–3 fragments, one per song that reached this layer type). Each fragment card displays:
- Chapter color background
- Emotional tagline from song-building
- Play/pause button for audio preview
- Vote button

**Audio preview:** Each audience member controls playback independently. Tapping play on a fragment starts that clip in the browser via the HTML5 Audio API. Tapping play on a different fragment auto-pauses the first. Volume is at the browser's default level. The natural social dynamics of a huddle (people sharing phones, taking turns, or just listening to the ambient mix of everyone's phones) are part of the experience. Preview files are pre-rendered static mp3s served from `public/audio/previews/`.

**Voting within the group:** Transparent — group members can see how many votes each fragment has. Votes can be changed freely during the deliberation window. This is the opposite of the blind song-building vote; within a small group, transparency encourages real discussion and convergence.

**Timer:** Configurable duration (default: 120 seconds). When the timer expires:
1. The fragment with the most votes in each group wins (**simple majority**). Ties broken randomly.
2. The chosen fragment is locked for each group
3. **Ambassador volunteering** begins immediately after fragment selection

**Ambassador selection:** After the fragment is chosen, each group member sees a prompt: "Will you carry this forward?" with Accept/Decline buttons. Volunteering window: configurable (default: 15 seconds).
- If exactly 1 person volunteers → they are the ambassador
- If multiple volunteer → one is selected randomly
- If nobody volunteers → the layer is **forfeited**. NPC acknowledges: this part of the mind couldn't find its voice. The layer will be skipped in the ceremony.

**Edge cases:**
- **Single-fragment layer types** (only one song reached this layer): the deliberation is trivially decided — the one available fragment wins automatically. The group still goes through the ambassador selection.
- **Single-member groups:** one person makes all decisions — they choose the fragment, they are the ambassador by default (no volunteering step needed).
- **Empty groups:** skipped entirely — no deliberation, no ambassador, layer forfeited.

### Phase 4: Ceremony

The performer returns to the stage (or is about to — the ceremony is the transition point). The system calls ambassadors one by one in a **fixed configurable order** (set in `default-show.json`, e.g., `[bass, drums, pad, melody, harmony, fx1, fx2]`).

**Ceremony flow per layer:**
1. The system announces the next layer (NPC text on phones + projector display: layer symbol, color, label)
2. The ambassador for that layer is called — their phone enters **altar-ready mode**
3. The ambassador approaches the altar on stage
4. The ambassador places their phone face-down on the altar surface
5. The phone detects the face-down + still position via Device Orientation API (~2 second hold)
6. On detection: lock-in event fires to server → audio activation (quantized to next bar boundary, fade-in per existing gain config) → phone vibrates once → screen illuminates with confirmation
7. Ambassador picks up phone, returns to seat
8. System advances to next layer

**Altar lock-in detection (Device Orientation API):**
```typescript
// Detection logic (runs on ambassador's phone during altar-ready mode)
interface AltarDetectionConfig {
  faceDownThreshold: number;       // degrees from face-down (default: 30°)
  stillnessThreshold: number;      // max acceleration delta (default: 0.5 m/s²)
  holdDurationMs: number;          // how long face-down + still must be sustained (default: 2000)
}

// DeviceOrientationEvent: check if phone is face-down
// Face-down = screen pointing toward ground
// Using absolute orientation: when face-down, the z-axis accelerometer reads ~+9.8 m/s²
// (gravity pulling "up" through the back of the phone)
// OR using beta/gamma: beta ≈ ±180° indicates face-down
//
// The detection fires when:
// 1. Phone is within faceDownThreshold degrees of perfectly face-down
// 2. Accelerometer readings are stable (delta < stillnessThreshold) for holdDurationMs
// 3. Both conditions sustained simultaneously
```

**Forfeited layers:** Skipped in the ceremony order. NPC may acknowledge briefly. No audio activation for that layer.

**Ceremony completion:** After all non-forfeited layers have been locked in, the ceremony ends. The song now plays with all locked fragments active. The performer takes over for the performer mix phase.

**Audio activation during ceremony:** Each lock-in unmutes the fragment's Ableton track, quantized to the next bar boundary, with the standard fade-in (per `GainConfig.ceremonySwellBeats`). The song assembles layer by layer — each ambassador's lock-in adds a new voice to the growing mix. By the last lock-in, the audience hears the complete assembled song.

### NPC System (Finale)

The NPC is a narrative voice during the finale, delivered via terminal-style typeface on audience phones and the projector.

**Delivery:** Text appears briefly, disappears between messages. No auto-scrolling history — each message replaces the last.

**Control model:** Event-driven messages for key moments + manual overrides from controller.

**Event-driven messages (configurable text in `default-show.json`):**
- Performer abandonment: "He's gone. We need to do this ourselves."
- Assembly start: "Choose your role. Find each other."
- Assembly timer warning (e.g., 10s remaining): "Decide now."
- Deliberation start: "Listen. Decide together."
- Empty group detected: "No one chose [layer label]. We'll go without it."
- Ambassador selected: "[Layer label] has its voice."
- No ambassador (forfeit): "[Layer label] goes silent. Not every part survives."
- Ceremony start: "One by one. Bring it forward."
- Layer locked in: brief acknowledgment (varies by layer)
- Final layer locked: "That's all of us."
- Ceremony complete / performer return: "He's back. Show him what we built."

**Manual overrides:** Performer has a bank of pre-written NPC lines on the controller, organized by phase, plus a free-text input for improvised lines.

**Pacing:** NPC should NOT speak at every moment. The silence between messages — filled by music building layer by layer — is where the emotional weight lives.

### Phase 5: Performer Mix

The performer returns to take control of the mix. This is a live performance tool.

**Initial state:** The performer mix begins with the fragments locked in during the ceremony as the active layers. Forfeited layers start muted.

**Mixing Surface (controller):**
- 7 rows (one per layer type) × 6 columns (Song 1 A, Song 1 B, Song 2 A, Song 2 B, Song 3 A, Song 3 B)
- Each cell is a fragment. Tapping a cell **queues** it to activate at the next loop boundary.
- Active fragment in each row is highlighted
- Pending (queued) fragment shows distinct visual (pulsing border, countdown)
- Only one fragment per row active at a time — tapping a new one in the same row queues a swap
- Tap the active fragment to queue a **mute** for that row at next boundary
- Tap a pending fragment again to **cancel** (dequeue)
- **All changes fire simultaneously at the loop boundary** — performer builds up multiple changes, they all land on the downbeat

**Loop position indicator:** Progress bar or radial timer showing position within current 8-bar loop and time until next boundary. This is the performance clock.

**Snapshot presets:** Configurable buttons that queue an entire mix state (all 7 layers set to specific fragments) in one tap. Useful for rehearsed structural jumps.

**Live performance tracks:** Additional on/off toggles for tracks not in the fragment pool — vocal mic, live synth, etc. These are the performer's secret weapon, the element the audience never had access to.

**Projector mirror:** The projector shows a simplified, beautified version of the mixing grid. Active fragments glow with chapter colors. Pending changes pulse. Loop position indicator visible. The audience watches the performer "DJ" with a legible interface.

**Pending changes queue:**
```typescript
interface PendingChange {
  layerType: LayerType;
  fragmentId: string | null;    // null = mute this layer
  queuedAt: number;
}
```

At each loop boundary, the timing engine:
1. Collects all pending changes
2. Fires corresponding OSC commands simultaneously (mute outgoing, unmute incoming)
3. Clears the pending queue
4. Broadcasts updated state to all clients

**Crossfade:** When swapping fragments in a role, Ableton handles a ~1 bar crossfade (old fragment fades out, new one fades in, overlapping at the loop boundary).

### Finale State

```typescript
interface FinaleState {
  phase: 'elegy' | 'assembly' | 'deliberation' | 'ceremony' | 'performer_mix';

  // Fragment availability (computed from song-building results)
  availableFragments: Fragment[];     // Winners only (for group deliberation)
  allFragments: Fragment[];           // All 42 (for performer mixing surface)
  lockedFragments: Fragment[];        // Losers + unreached (for elegy display)

  // Group assembly state
  assembly: {
    groups: Map<LayerType, UserId[]>;       // layerType → array of user IDs
    undecidedUsers: UserId[];               // Users who haven't chosen yet
    timerRemaining: number;                 // ms
    timerDuration: number;                  // ms (total)
  };

  // Deliberation state
  deliberation: {
    groupVotes: Map<LayerType, Map<UserId, string>>;  // layerType → (userId → fragmentId)
    chosenFragments: Map<LayerType, string | null>;    // layerType → fragmentId or null (after timer)
    ambassadorVolunteers: Map<LayerType, UserId[]>;    // layerType → volunteer user IDs
    ambassadors: Map<LayerType, UserId | null>;        // layerType → chosen ambassador or null
    timerRemaining: number;                            // ms (deliberation timer)
    volunteerTimerRemaining: number | null;            // ms (ambassador volunteering timer, null if not active)
  };

  // Ceremony state
  ceremony: {
    layerOrder: LayerType[];                    // Fixed configurable order
    currentIndex: number;                       // Index into layerOrder
    currentAmbassador: UserId | null;           // Ambassador currently called
    altarReady: boolean;                        // Whether current ambassador's phone is in altar-ready mode
    lockedLayers: Map<LayerType, string>;        // layerType → fragmentId (locked in at altar)
    forfeitedLayers: LayerType[];               // Layers with no ambassador
    ceremonyComplete: boolean;
  };

  // NPC state
  npc: {
    currentMessage: string | null;
  };

  // Performer mix state
  performerMix: {
    activeLayers: Map<LayerType, string | null>;  // layerType → fragmentId or null (muted)
    pendingChanges: PendingChange[];
    loopPosition: number;             // 0.0 to 1.0 within current 8-bar loop
    loopCount: number;                // Total loops since finale started
    liveTracksActive: string[];       // IDs of active live performance tracks
  };
}
```

---

## Musical Design Specification

### Shared Compatibility Universe

All fragments across all three songs share:
- **Key:** B minor (B natural minor scale: B, C#, D, E, F#, G, A)
- **BPM:** Fixed (target: 120 BPM, configurable)
- **Loop length:** Exactly 8 bars
- **Time signature:** 4/4
- **Chord progression:** Same progression across all songs
- **Harmonic rhythm:** One chord per 2 bars (4 chords across 8 bars)

### Chord Progression & Harmonic Rules

**Sync points:** Bars 1, 3, 5, and 7 are harmonic sync points. Every harmonically specific fragment must agree on the chord at these bar boundaries.

**Passing chords:** Between sync points, individual fragments may use passing chords lasting less than 1 beat. These read as melodic movement, not as competing harmony. Passing material must be short and directional (heading toward the next sync point chord).

**Harmonic specificity tiers:**
- **Harmonically specific** (Melody): defines the chord progression explicitly. Only one harmonically specific fragment should dominate at a time.
- **Harmonically compatible** (Pad, Harmony, Bass): uses chord tones, pentatonic notes, or sustained intervals that work over all chords. Emphasize roots, fifths, and pentatonic (B, D, E, F#, A) for maximum cross-fragment safety.
- **Harmonically neutral** (Drums, FX1, FX2): no pitched content or heavily filtered. Compatible with everything.

### Song Differentiation

Same key, same BPM, same progression — songs feel different via:
- **Orchestration:** Different instruments, timbres, articulations
- **Groove:** Song 1 = straight, Song 2 = swung, Song 3 = half-time feel
- **Register:** Song 1 = bright/high, Song 2 = warm/mid, Song 3 = dark/low + airy highs
- **Density & space:** Song 1 = tight and driving, Song 2 = spacious and breathing, Song 3 = sparse and evasive
- **Build order:** Staggered layer ordering makes each song start from a different musical foundation

### EQ Fencing (Spectral Separation)

Each layer type occupies a designated frequency range. EQ cuts on each track remove energy from other layers' ranges:
- **Bass:** Owns 60–200 Hz. Low-pass filter at ~250 Hz.
- **Drums:** Key hits span spectrum (kick ~60–100 Hz, snare ~200–500 Hz, hi-hats ~8kHz+). No single fence; manage via arrangement.
- **Pad:** 200–500 Hz. Cut below 200 Hz (bass territory) and above 2 kHz (melody territory).
- **Melody:** 500 Hz – 2 kHz. Cut below 400 Hz.
- **Harmony:** 1–4 kHz. Higher register than pad to avoid competition.
- **FX1, FX2:** Extremes and gaps. Very high shimmer, very low rumble, or sweeping through spectrum.

### Production Guidelines

- **Bar 1 is sacred:** clean downbeat, no fills bleeding across the loop point. All fragments must re-sync cleanly at bar 1.
- **Bars 7–8 are free:** variations, fills, builds, resolving phrases. This gives each loop a sense of "going somewhere."
- **Use silence:** fragments with rhythmic holes allow other fragments to shine through when combined.
- **Velocity dynamics:** vary note velocities within each 8-bar loop. Louder on downbeats, softer on offbeats. Slight crescendo toward bar 5.
- **Micro-timing/swing:** use Ableton's groove pool. Different swing amounts per song for differentiation.
- **Timbre evolution:** automate one parameter per fragment across 8 bars (filter opening, reverb swell, chorus depth).
- **Reverb discipline:** reverb on melody, harmony, FX. Keep bass and drums dry or nearly dry.

### Audio Preview Production

Each of the 42 fragment clips must be exported as a standalone audio file for in-browser preview:
- **Format:** mp3, 128kbps (adequate quality for phone speakers; small file size for fast loading)
- **Duration:** 4–8 bars recommended. Full 8-bar loop acceptable. Shorter excerpts encourage turn-taking during group deliberation.
- **Naming:** `preview-{songIndex}-{layerIndex}-{option}.mp3` (e.g., `preview-0-2-A.mp3`)
- **Content:** Should start cleanly on bar 1 and ideally loop well, though looping is not required for preview purposes
- **Total file count:** Up to 42 files (3 songs × 7 layers × 2 options), though only available fragments will be loaded by clients

---

## Audio Engine & Ableton Integration

### Track Layout

**Song-building tracks** (3 songs × 7 layers × 2 options = 42 tracks):
- Track index: `songIndex * (layersPerSong * 2) + layerIndex * 2 + optionOffset`
  - `optionOffset`: 0 for Option A, 1 for Option B
- With 7 layers per song: tracks 0–41
- Example: Song 0, Layer 2, Option B = `0 * 14 + 2 * 2 + 1 = track 5`
- Example: Song 1, Layer 0, Option A = `1 * 14 + 0 * 2 + 0 = track 14`
- Example: Song 2, Layer 3, Option A = `2 * 14 + 3 * 2 + 0 = track 34`

**Live performance tracks** (beyond index 41): vocal mic, live synth, etc. Not part of the fragment system. Controlled only by the performer.

**Song rejection effect:** A return track with configurable effects (filter sweep, distortion, reverb tail) triggered via OSC. All song-building tracks route through this return.

### Playback Modes

**Song-building:**
- Audition: briefly unmute/solo Option A, then Option B (quantized transitions)
- Lock-in: unmute chosen option's track, mute unchosen
- Stack accumulates: previously locked layers stay unmuted

**Collapse:**
- Triggered when health bar reaches 0
- Collapse effect activates on return track (distortion, filter sweep, reverb tail)
- Rapid fade or filter sweep on all active tracks for this attempt
- After gesture completes, mute all tracks for the collapsed attempt

**Song rejection:**
- Triggered via controller for completed songs only
- Rejection effect on return track activates (TBD: distinct from collapse effect — configurable)
- After effect completes, all tracks for this attempt are muted

**Finale — Ceremony lock-in:**
- Each altar lock-in: unmute the chosen fragment's track, quantized to next bar boundary
- Fade in per `GainConfig.ceremonySwellBeats` (e.g., ~2 bars)
- Layers accumulate: previously locked ceremony layers stay unmuted

**Finale — Performer mix:**
- Pending changes queue fires all mute/unmute commands simultaneously at loop boundary
- Swaps within a role: ~1 bar crossfade (old fades out, new fades in)
- Muting a role: fade out over ~1 bar at loop boundary

### OSC Protocol

Uses the **AbletonOSC** plugin (by ideoforms). All addresses follow the `/live/*` namespace.

**Server → AbletonOSC (Port 11000)**

| Address | Arguments | Description |
|---------|-----------|-------------|
| `/live/test` | - | Connectivity test |
| `/live/song/start_listen/beat` | - | Subscribe to beat events |
| `/live/song/stop_listen/beat` | - | Unsubscribe from beat events |
| `/live/song/start_listen/tempo` | - | Subscribe to tempo changes |
| `/live/song/stop_listen/tempo` | - | Unsubscribe from tempo changes |
| `/live/song/get/tempo` | - | Query current tempo |
| `/live/song/get/is_playing` | - | Query transport state |
| `/live/song/start_playing` | - | Start global transport |
| `/live/song/stop_playing` | - | Stop global transport |
| `/live/song/continue_playing` | - | Resume from current position |
| `/live/clip/fire` | `trackIndex`, `clipIndex` | Fire clip (always slot 0) |
| `/live/clip/stop` | `trackIndex`, `clipIndex` | Stop clip |
| `/live/track/set/mute` | `trackIndex`, `mute` | Mute (1) / unmute (0) track |
| `/live/device/set/parameter/value` | `trackIndex`, `deviceIndex`, `paramIndex`, `value` | Set device parameter |
| `/live/return/set/mute` | `returnIndex`, `mute` | Mute/unmute return track |

**AbletonOSC → Server (Port 11001)**

| Address | Arguments | Description |
|---------|-----------|-------------|
| `/live/test` | `response` | Connectivity test response |
| `/live/song/get/beat` | `beatNumber` | Beat event (when subscribed) |
| `/live/song/get/tempo` | `bpm` | Current tempo (on query or change) |
| `/live/song/get/is_playing` | `isPlaying` | Transport state (1 = playing, 0 = stopped) |

### Fallback Mode (No Ableton)

Unchanged from V1. Timing engine uses JS timers; audio cues are logged but not sent.

### Environment Variables

```bash
# Server
PORT=3000
DATABASE_PATH=./db/show.sqlite

# Timing
TIMING_ENGINE_ENABLED=true

# OSC
OSC_ENABLED=true
OSC_SEND_PORT=11000
OSC_RECEIVE_PORT=11001
OSC_HOST=127.0.0.1
MOCK_BPM=120

# Health Bar
DEFAULT_DRAIN_FACTOR=0.5
DEFAULT_LAYER_MULTIPLIERS=0.5,0.6,0.8,1.0,1.3,1.6,2.0
COLLAPSE_ANIMATION_MS=5000

# Finale — Assembly
ASSEMBLY_TIMER_MS=60000
ASSEMBLY_GRACE_PERIOD_MS=15000

# Finale — Deliberation
DELIBERATION_TIMER_MS=120000
AMBASSADOR_VOLUNTEER_TIMER_MS=15000

# Finale — Ceremony
CEREMONY_LAYER_ORDER=bass,drums,pad,melody,harmony,fx1,fx2

# Audio Previews
AUDIO_PREVIEW_PATH=/audio/previews
```

---

## Data Models

### User

```typescript
interface User {
  id: UserId;                   // Persistent across reconnection (stored client-side)
  seatId: SeatId | null;        // From QR code scan; null if joined without QR
  connected: boolean;
  joinedAt: number;
}
```

### Show State

```typescript
interface ShowState {
  id: string;                          // Unique show instance
  phase: ShowPhase;
  currentAttemptIndex: number;         // 0, 1, 2
  attempts: AttemptState[];            // Length 3, pre-initialized
  users: Map<UserId, User>;
  finaleState: FinaleState | null;     // Populated at finale_elegy
  config: ShowConfig;
  version: number;                     // Increments on every state change
  lastUpdated: number;
  paused: boolean;
}

interface AttemptState {
  index: number;                       // 0, 1, 2
  chapter: Chapter;                    // 'ambition' | 'love' | 'avoidance'
  layerPlan: LayerConfig[];            // Always length 7
  currentLayerIndex: number;
  currentLayerPhase: LayerPhase;
  layerResults: LayerResult[];         // Populated as layers resolve
  votes: LayerVote[];                  // All votes for this attempt
  healthBar: HealthBarState;
  status: 'pending' | 'in_progress' | 'completed' | 'collapsed';
  collapsedAtLayer: number | null;     // Layer index where collapse occurred, or null
}

type Chapter = 'ambition' | 'love' | 'avoidance';
```

### Show Config

```typescript
interface ShowConfig {
  layersPerAttempt: number;            // Always 7
  attempts: AttemptConfig[];           // Length 3
  finale: FinaleConfig;
  timing: TimingConfig;
  lobby: {
    waitingMessage: string;
  };
  seatIds: SeatId[];
}

interface AttemptConfig {
  chapter: Chapter;
  title: string;
  layers: LayerConfig[];              // 7 layers, staggered per song
  drainFactor: number;                // Health bar base drain multiplier for this attempt
  layerMultipliers: number[];         // Per-layer scaling factors (length 7)
}

interface FinaleConfig {
  assemblyTimerMs: number;             // Duration of group assembly phase
  assemblyGracePeriodMs: number;       // Grace period after assignment before deliberation
  deliberationTimerMs: number;         // Duration of group deliberation phase
  ambassadorVolunteerTimerMs: number;  // Duration of ambassador volunteering window
  ceremonyLayerOrder: LayerType[];     // Fixed order for ambassador call-ups
  audioPreviewPath: string;            // Base URL path for preview audio files
  layerLabels: Map<LayerType, string>; // Configurable display labels for assembly cards (e.g., "The Heartbeat")
  npcMessages: NpcMessageConfig[];     // Event-driven NPC messages (event key → text)
}

interface NpcMessageConfig {
  event: string;                       // Event key (e.g., 'performer_abandonment', 'assembly_start', 'layer_locked')
  layerType?: LayerType;               // Optional: specific to a layer type
  text: string;                        // The NPC message text
}

interface TimingConfig {
  auditionDurationMs: number;
  votingWindowMs: number;
  revealSequenceDurationMs: number;
  rejectionEffectDurationMs: number;
  beatsPerLoop: number;
  auditionsPerLayer: number;
  gain: GainConfig;
}

interface GainConfig {
  entryGain: number;
  entrySwellBeats: number;
  holdBars: number;
  exitFadeBeats: number;
  lockInFadeBeats: number;
  collapseFadeBeats: number;
  ceremonySwellBeats: number;    // Beats to swell ceremony-activated fragments (replaces consensusSwellBeats)
  unityGainValue: number;
  stepsPerBeat: number;
}

interface Fragment {
  id: string;
  songIndex: number;                   // 0, 1, 2
  layerIndex: number;
  option: 'A' | 'B';
  chapter: Chapter;
  layerType: LayerType;
  displayLabel: string;               // Emotional tagline from layer config
  audioRef: AudioReference;           // Ableton track index
  previewAudioPath: string;           // URL path to preview audio file
}
```

---

## Conductor (Pure State Machine)

The Conductor is a pure logic module with no I/O. It receives commands, validates them, updates state, and emits events.

### Commands (Input)

```typescript
type ConductorCommand =
  // Show flow
  | { type: 'ADVANCE_PHASE' }
  | { type: 'JUMP_TO_PHASE'; phase: ShowPhase; attemptIndex?: number }
  | { type: 'PAUSE' }
  | { type: 'RESUME' }

  // Song-building
  | { type: 'START_AUDITION' }
  | { type: 'OPEN_VOTING' }
  | { type: 'CLOSE_VOTING' }
  | { type: 'SUBMIT_VOTE'; userId: UserId; choice: 'A' | 'B' }
  | { type: 'FORCE_OPTION'; choice: 'A' | 'B' }
  | { type: 'EXTEND_VOTE_TIMER'; additionalMs: number }
  | { type: 'RERUN_VOTE' }

  // Health Bar
  | { type: 'SET_DRAIN_FACTOR'; factor: number }
  | { type: 'SET_HEALTH'; value: number }
  | { type: 'FORCE_COLLAPSE' }

  // Song Rejection
  | { type: 'TRIGGER_REJECTION' }

  // Finale — Setup
  | { type: 'SETUP_FINALE' }

  // Finale — Assembly
  | { type: 'START_ASSEMBLY' }
  | { type: 'JOIN_GROUP'; userId: UserId; layerType: LayerType }
  | { type: 'ASSEMBLY_TIMER_EXPIRED' }
  | { type: 'FORCE_ASSIGN_USER'; userId: UserId; layerType: LayerType }
  | { type: 'EXTEND_ASSEMBLY_TIMER'; additionalMs: number }
  | { type: 'FORCE_END_ASSEMBLY' }

  // Finale — Deliberation
  | { type: 'START_DELIBERATION' }
  | { type: 'SUBMIT_GROUP_VOTE'; userId: UserId; layerType: LayerType; fragmentId: string }
  | { type: 'DELIBERATION_TIMER_EXPIRED' }
  | { type: 'VOLUNTEER_AS_AMBASSADOR'; userId: UserId; layerType: LayerType }
  | { type: 'AMBASSADOR_VOLUNTEER_TIMER_EXPIRED'; layerType: LayerType }
  | { type: 'FORCE_FRAGMENT_SELECTION'; layerType: LayerType; fragmentId: string }
  | { type: 'EXTEND_DELIBERATION_TIMER'; additionalMs: number }
  | { type: 'FORCE_END_DELIBERATION' }

  // Finale — Ceremony
  | { type: 'START_CEREMONY' }
  | { type: 'CALL_NEXT_AMBASSADOR' }
  | { type: 'ALTAR_LOCK_IN'; userId: UserId; layerType: LayerType }
  | { type: 'FORCE_LOCK_IN'; layerType: LayerType }
  | { type: 'FORFEIT_LAYER'; layerType: LayerType }
  | { type: 'SKIP_TO_LAYER'; layerType: LayerType }

  // Finale — NPC
  | { type: 'SEND_NPC_MESSAGE'; message: string }

  // Finale — Performer Mix
  | { type: 'START_PERFORMER_MIX' }
  | { type: 'QUEUE_FRAGMENT'; layerType: LayerType; fragmentId: string | null }
  | { type: 'CANCEL_PENDING'; layerType: LayerType }
  | { type: 'FIRE_PENDING_CHANGES' }
  | { type: 'LOAD_SNAPSHOT'; snapshot: Map<LayerType, string | null> }
  | { type: 'TOGGLE_LIVE_TRACK'; trackId: string }

  // Audio
  | { type: 'AUDIO_TRANSPORT'; action: 'play' | 'stop' }
  | { type: 'AUDIO_PANIC' }
  | { type: 'RESET_UTILITIES' }

  // Connection
  | { type: 'USER_CONNECT'; userId: UserId; seatId?: SeatId }
  | { type: 'USER_DISCONNECT'; userId: UserId }

  // Recovery
  | { type: 'EXPORT_STATE' }
  | { type: 'IMPORT_STATE'; state: ShowState }
  | { type: 'FORCE_RECONNECT_ALL' }
  | { type: 'RESET_TO_LOBBY'; preserveUsers: boolean };
```

### Events (Output)

```typescript
type ConductorEvent =
  // Show flow
  | { type: 'SHOW_PHASE_CHANGED'; phase: ShowPhase; attemptIndex?: number }
  | { type: 'PAUSED' }
  | { type: 'RESUMED' }

  // Song-building
  | { type: 'LAYER_PHASE_CHANGED'; attemptIndex: number; layerIndex: number; phase: LayerPhase }
  | { type: 'VOTE_RECEIVED'; userId: UserId; attemptIndex: number; layerIndex: number }
  | { type: 'VOTE_RESULT'; attemptIndex: number; layerIndex: number; result: VoteResult }
  | { type: 'LAYER_LOCKED_IN'; attemptIndex: number; layerIndex: number; winner: 'A' | 'B' }
  | { type: 'HEALTH_BAR_DRAINED'; attemptIndex: number; layerIndex: number; drain: HealthBarDrain }
  | { type: 'ATTEMPT_COLLAPSED'; attemptIndex: number; atLayer: number; healthBar: HealthBarState }
  | { type: 'ATTEMPT_COMPLETED'; attemptIndex: number }
  | { type: 'SONG_REJECTED'; attemptIndex: number }

  // Finale — Setup
  | { type: 'FINALE_SETUP_COMPLETE'; availableFragments: Fragment[]; lockedFragments: Fragment[] }

  // Finale — Assembly
  | { type: 'ASSEMBLY_STARTED'; timerDuration: number }
  | { type: 'GROUP_MEMBERSHIP_CHANGED'; groups: Map<LayerType, UserId[]>; undecidedCount: number }
  | { type: 'ASSEMBLY_COMPLETE'; groups: Map<LayerType, UserId[]>; emptyGroups: LayerType[] }

  // Finale — Deliberation
  | { type: 'DELIBERATION_STARTED'; timerDuration: number }
  | { type: 'GROUP_VOTE_UPDATED'; layerType: LayerType; votes: Map<string, number> }
  | { type: 'FRAGMENT_CHOSEN'; layerType: LayerType; fragmentId: string }
  | { type: 'AMBASSADOR_VOLUNTEERED'; layerType: LayerType; userId: UserId }
  | { type: 'AMBASSADOR_SELECTED'; layerType: LayerType; userId: UserId }
  | { type: 'LAYER_FORFEITED'; layerType: LayerType }
  | { type: 'DELIBERATION_COMPLETE' }

  // Finale — Ceremony
  | { type: 'CEREMONY_STARTED'; layerOrder: LayerType[] }
  | { type: 'AMBASSADOR_CALLED'; layerType: LayerType; userId: UserId }
  | { type: 'ALTAR_LOCK_IN_DETECTED'; layerType: LayerType; fragmentId: string }
  | { type: 'CEREMONY_LAYER_LOCKED'; layerType: LayerType; fragmentId: string }
  | { type: 'CEREMONY_LAYER_SKIPPED'; layerType: LayerType }
  | { type: 'CEREMONY_COMPLETE'; lockedLayers: Map<LayerType, string> }

  // Finale — NPC
  | { type: 'NPC_MESSAGE'; message: string }

  // Finale — Performer Mix
  | { type: 'PERFORMER_MIX_STARTED' }
  | { type: 'PENDING_CHANGES_FIRED'; changes: PendingChange[] }
  | { type: 'MIX_STATE_UPDATED'; activeLayers: Map<LayerType, string | null> }

  // Audio
  | { type: 'AUDIO_CUE'; cue: AudioCue }

  // State
  | { type: 'STATE_UPDATED'; version: number };

interface VoteResult {
  winner: 'A' | 'B';
  consensus: number;           // Winning side's proportion
  votesA: number;
  votesB: number;
  totalVotes: number;
  drain: HealthBarDrain;
}
```

---

## WebSocket Protocol

### State Sync Strategy
Full state syncs on every mutation:
- **Controller**: Full serialized state (including per-group vote distributions, ambassador status, altar state)
- **Projector**: Public filtered state (group sizes, vote distributions, ceremony progress — no individual user data)
- **Audience**: Personalized state (their group assignment, their group's votes, their ambassador status, their altar-ready state)

### Client → Server Events

| Event | Payload | Sender |
|-------|---------|--------|
| `join` | `{ userId?, seatId?, mode }` | All |
| `reconnect` | `{ userId, showId, lastVersion }` | All |
| `vote` | `{ choice: 'A' \| 'B' }` | Audience (song-building) |
| `join_group` | `{ layerType }` | Audience (assembly phase) |
| `group_vote` | `{ fragmentId }` | Audience (deliberation phase) |
| `volunteer_ambassador` | `{}` | Audience (deliberation phase, after fragment chosen) |
| `altar_lock_in` | `{}` | Audience (ceremony phase, ambassador only) |
| `command` | `ConductorCommand` | Controller |

### Server → Client Events

| Event | Payload | Recipients |
|-------|---------|------------|
| `state_sync` | `ShowState` (filtered per client type) | All |
| `identity` | `{ userId }` | New audience members |
| `group_update` | `{ groups: Map<LayerType, number>, undecided: number }` | Audience + Projector (during assembly, ~2 Hz) |
| `npc_message` | `{ message: string }` | Audience + Projector |
| `ambassador_called` | `{ layerType, userId }` | All (during ceremony) |
| `altar_ready` | `{}` | Single audience member (the called ambassador) |
| `altar_confirmed` | `{ layerType, fragmentId }` | All (after successful altar lock-in) |
| `error` | `{ message }` | Controller |

**Note on group updates:** Sent as a separate event during assembly at ~2 Hz for responsive group size displays, NOT as part of state_sync.

---

## Persistence Layer

### SQLite with WAL Mode

Unchanged from V1.

### Schema

```sql
CREATE TABLE shows (
  id TEXT PRIMARY KEY,
  state JSON NOT NULL,
  version INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  show_id TEXT NOT NULL,
  seat_id TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (show_id) REFERENCES shows(id)
);

CREATE TABLE votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  show_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  attempt_index INTEGER NOT NULL,
  layer_index INTEGER NOT NULL,
  choice TEXT NOT NULL CHECK(choice IN ('A', 'B')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (show_id) REFERENCES shows(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE finale_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  show_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  layer_type TEXT NOT NULL,
  auto_assigned BOOLEAN NOT NULL DEFAULT 0,     -- TRUE if randomly assigned at timer expiry
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (show_id) REFERENCES shows(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE finale_group_votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  show_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  layer_type TEXT NOT NULL,
  fragment_id TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (show_id) REFERENCES shows(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE ceremony_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  show_id TEXT NOT NULL,
  layer_type TEXT NOT NULL,
  ambassador_user_id TEXT,                       -- NULL if forfeited
  fragment_id TEXT,                               -- NULL if forfeited
  event_type TEXT NOT NULL CHECK(event_type IN ('locked', 'forfeited')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (show_id) REFERENCES shows(id)
);
```

**Removed from V2:** `consensus_rounds` table.

### Persistence Strategy & Recovery

Unchanged from V1. Persist after EVERY state change. Atomic SQLite transactions. Stateless clients. Automatic reconnection with exponential backoff.

---

## Recovery & Robustness

Unchanged from V1. See original architecture for heartbeat, state versioning, backup snapshots, and fallback modes.

**Finale-specific recovery notes:**
- If an ambassador disconnects during the ceremony, the controller can force-lock-in or forfeit the layer
- If assembly or deliberation timers expire during a server restart, the system should recover to the post-timer state (groups assigned, fragments chosen by majority of recorded votes)
- Audio preview files are static assets and require no server state

---

## Visual Identity System

### Chapter Identity (consistent across all UIs)

| Chapter | Color | Icon | Usage |
|---------|-------|------|-------|
| Ambition | TBD | TBD | Song 1, fragment badges |
| Love | TBD | TBD | Song 2, fragment badges |
| Avoidance | TBD | TBD | Song 3, fragment badges |

### Layer Identity (consistent across all 3 attempts + finale groups)

| Layer Type | Color | Symbol | Label |
|------------|-------|--------|-------|
| Melody | TBD | ✦ | "The voice" |
| Drums | TBD | ▲ | "The heartbeat" |
| Pad | TBD | ◆ | "The warmth" |
| Bass | TBD | ■ | "The ground" |
| Harmony | TBD | ● | "The color" |
| FX1 | TBD | ~ | "The shimmer" |
| FX2 | TBD | ∿ | "The shadow" |

*Placeholders — lock before production. Labels are configurable in `default-show.json`.*

### Option Identity (A vs B within a layer)
- Option A: layer color, **solid** style
- Option B: layer color, **outlined** style

---

## Folder Structure

```
solo-show/
├── ARCHITECTURE.md              # This document (V3 — source of truth)
├── MIGRATION.md                 # Migration guide from V2 to V3
├── PROMPTS.md                   # AI agent implementation prompts
├── CHANGELOG.md                 # Human-readable change history with intent
├── CLAUDE.md                    # AI agent instructions and context
├── DECISIONS.md                 # Open questions and resolved decisions
├── README.md                    # Setup and run instructions
│
├── conductor/                   # Pure game logic (no I/O)
│   ├── index.ts                 # Exports
│   ├── conductor.ts             # State machine (show phases + layer phases)
│   ├── voting.ts                # Blind vote tallying + health bar drain
│   ├── health-bar.ts            # Health bar state management
│   ├── assembly.ts              # Group assembly logic (join, random assign, timer)
│   ├── deliberation.ts          # Group deliberation (voting, majority, ambassador selection)
│   ├── ceremony.ts              # Ceremony sequencing (ambassador calls, altar lock-in, forfeits)
│   ├── performer-mix.ts         # Pending changes queue, mix state, snapshots
│   ├── fragments.ts             # Fragment generation from attempt results
│   ├── npc.ts                   # NPC event-driven message logic
│   ├── types.ts                 # Shared type definitions
│   └── __tests__/               # Unit tests
│
├── server/                      # Custom server (Next.js + Socket.IO)
│   ├── index.ts                 # Entry point
│   ├── socket.ts                # Socket.IO event handlers
│   ├── persistence.ts           # SQLite layer
│   ├── recovery.ts              # State recovery and backup
│   ├── timing.ts                # Quantized timing engine (loop boundary detection)
│   ├── osc.ts                   # OSC bridge for Ableton
│   ├── audio-router.ts          # Maps AUDIO_CUE events to OSC messages
│   ├── __tests__/
│   └── tools/
│       └── osc-mock-ableton.ts  # Mock Ableton for testing
│
├── app/                         # Next.js App Router (pages)
│   ├── layout.tsx
│   ├── page.tsx                 # Landing/redirect
│   ├── audience/
│   │   └── page.tsx
│   ├── projector/
│   │   └── page.tsx
│   └── controller/
│       └── page.tsx
│
├── components/                  # React components
│   ├── song-building/
│   │   ├── OptionCards.tsx       # A/B voting cards
│   │   ├── RevealSequence.tsx   # Post-vote reveal animation
│   │   ├── HealthBar.tsx        # Health bar visualization
│   │   └── LayerProgress.tsx    # Completed/upcoming layer indicators
│   ├── finale/
│   │   ├── ElegyGrid.tsx        # Full fragment wreckage display
│   │   ├── AssemblyCards.tsx    # Layer-type group selection cards
│   │   ├── GroupIdentity.tsx    # "You are [Layer]" post-assignment display
│   │   ├── DeliberationBoard.tsx # Fragment preview + group voting UI
│   │   ├── AudioPreview.tsx     # In-browser audio preview player
│   │   ├── AmbassadorPrompt.tsx # Volunteer / ambassador selection UI
│   │   ├── CeremonyView.tsx     # Ceremony progress (non-ambassador audience)
│   │   ├── AltarReady.tsx       # Ambassador altar-ready mode (accelerometer listener)
│   │   ├── NpcDisplay.tsx       # Terminal-style NPC text
│   │   ├── MixingSurface.tsx    # Performer's 7×6 mixing grid (controller)
│   │   ├── MixingMirror.tsx     # Projector view of mixing state
│   │   └── LoopIndicator.tsx    # Loop position progress bar
│   ├── shared/
│   │   ├── ChapterBadge.tsx     # Chapter color/icon badge
│   │   ├── LayerIcon.tsx        # Layer type color/symbol
│   │   └── PhaseIndicator.tsx   # Current phase display
│   └── controller/
│       ├── ShowControls.tsx     # Phase control buttons
│       ├── VotingControls.tsx   # Vote management
│       ├── HealthBarControls.tsx # Drain factor adjustment
│       ├── AssemblyControls.tsx # Group size monitoring, timer control
│       ├── DeliberationControls.tsx # Per-group vote monitoring, timer control
│       ├── CeremonyControls.tsx # Ambassador management, force lock-in, forfeits
│       ├── NpcControls.tsx      # NPC line bank + manual fire
│       ├── MixingSurface.tsx    # Performer mix interface
│       ├── SnapshotPresets.tsx  # Quick-load mix configurations
│       └── MetricsPanel.tsx     # Telemetry dashboard
│
├── hooks/
│   ├── useSocket.ts             # Socket.IO connection + reconnection
│   ├── useShowState.ts          # Client-side state management
│   ├── useAudioPreview.ts       # Audio preview playback management
│   └── useAltarDetection.ts     # Device Orientation API altar lock-in detection
│
├── lib/
│   ├── socket-client.ts         # Socket.IO client setup
│   ├── storage.ts               # localStorage for client identity
│   ├── serialization.ts         # Map/Set JSON serialization
│   └── identity.ts              # Chapter/layer color+symbol mappings
│
├── public/
│   └── audio/
│       └── previews/            # Pre-rendered fragment audio files
│           ├── preview-0-0-A.mp3
│           ├── preview-0-0-B.mp3
│           └── ...              # (up to 42 files)
│
├── config/
│   ├── default-show.json        # Pre-configured attempts, layers, fragments, layer labels, ceremony order
│   ├── ableton-layout.json      # Track index mappings
│   └── npc-messages.json        # Event-driven NPC messages (replaces npc-triggers.json)
│
├── db/
│   └── schema.sql               # SQLite schema (V3)
│
├── next.config.js
├── tsconfig.json
├── package.json
└── .gitignore
```

---

## AI-First Development Practices

Unchanged from V1. See original architecture for context management, making changes, and handling design uncertainty guidelines.

**Updated test name examples:**
```typescript
test('health bar drains by losing proportion times drain factor times layer multiplier', ...)
test('blind vote does not expose split during voting window', ...)
test('attempt collapses when health bar reaches zero', ...)
test('completed attempt transitions to attempt_resolve for rejection', ...)
test('unreached layers are marked as locked fragments in finale', ...)
test('undecided users are randomly assigned to groups when assembly timer expires', ...)
test('empty groups are marked and skipped in ceremony', ...)
test('deliberation selects fragment by simple majority at timer expiry', ...)
test('ties in deliberation are broken randomly', ...)
test('ambassador is selected randomly when multiple volunteers', ...)
test('layer is forfeited when no ambassador volunteers', ...)
test('altar lock-in requires face-down + still for configured duration', ...)
test('ceremony lock-in triggers audio activation quantized to next bar boundary', ...)
test('performer mix initial state reflects ceremony lock-in results', ...)
test('performer pending changes all fire simultaneously at loop boundary', ...)
```

---

## Open Questions (To Be Resolved)

- [ ] **Audience phones during performer mix phase:** Go dark, minimal ambient visualization, or endorsement tap surface?
- [ ] **Song rejection audio effect:** Exact Ableton effect chain and OSC trigger method. Should be distinct from collapse effect.
- [ ] **Collapse audio effect:** Exact Ableton effect chain for when health bar hits zero. Should be distinct from rejection effect.
- [ ] **Exact chord progression:** B minor key confirmed; specific 4-chord sequence TBD pending Ableton exploration.
- [ ] Locked color/symbol assignments for layers + chapters
- [ ] Specific fragment display labels (emotional taglines per option)
- [ ] NPC text library (event-driven messages per phase)
- [ ] Projector visual design and animations (especially ceremony layer-by-layer build)
- [ ] Performer mix snapshot presets
- [ ] Live performance track configuration
- [ ] **Audio preview file length:** 4 bars vs full 8-bar loop — needs playtesting for deliberation flow
- [ ] **Ceremony pacing:** How long between ambassador call-ups? Performer-controlled (manual advance) or auto-timed?
- [ ] **Altar detection tuning:** Face-down threshold angle, stillness threshold, hold duration — needs device testing across iOS/Android
- [ ] **Assembly grace period:** How long after groups are assigned before deliberation timer starts? Enough for physical movement?
- [ ] **Deliberation with single-fragment layers:** Skip voting UI and go straight to ambassador selection, or show the single option for confirmation?

---

## Appendix A: What Changed from V1 → V2

### Removed Systems
- **Per-layer doubt thresholds** → replaced by Health Bar with cumulative drain and layer multipliers
- **Chapter assignment** → no chapter assignment in finale
- **Individual fragment selection** → replaced by consensus game (V2)
- **Fragment queue / rotation system** → replaced by consensus game + performer mix (V2)
- **Stewardship / safe parameter control** → removed entirely
- **Triangle steering / centroid** → removed entirely
- **Active slots (7-slot rotation)** → replaced by role-typed layer activation
- **Audio metering (M4L → projector)** → removed (may be re-added for projector visuals)

### New Systems (V2)
- **Health Bar** with cumulative drain + configurable layer multipliers
- **Mechanical collapse** when health bar reaches zero
- **Blind vote** with reveal sequence
- **Song rejection** for completed songs
- **Consensus Game** (convergence meter, timed rounds, threshold softening) — *replaced in V3*
- **NPC system** (hybrid auto/manual) — *simplified in V3*
- **Performer mixing surface** (7×6 grid, pending changes queue, loop quantization)
- **Snapshot presets** for performer mix
- **Musical design specification** (harmonic rules, EQ fencing, production guidelines)

---

## Appendix B: What Changed from V2 → V3

### Removed Systems
- **Consensus Game** — convergence meter, timed consensus rounds, threshold softening, convergence calculation. Replaced by physically embodied group assembly + deliberation + ceremony.
- **Convergence Meter** — no longer needed; groups vote transparently within themselves.
- **NPC auto-trigger system** — the complex per-round auto-trigger conditions are replaced by simpler event-driven messages tied to phase transitions and key moments.
- **`consensus_rounds` DB table** — replaced by `finale_groups`, `finale_group_votes`, and `ceremony_events` tables.
- **`useConvergence` hook** — removed (no convergence meter to animate).
- **`ConsensusBoard.tsx`** and **`ConvergenceMeter.tsx`** components — removed.
- **`consensus-game.ts`** conductor module — removed.
- **`npc-triggers.json`** config — replaced by `npc-messages.json` (event-driven).
- **Web Speech Synthesis** — considered and deferred.
- **Vibration API** — considered and deferred (except single vibration on altar lock-in confirmation).

### New Systems
- **Group Assembly** — timer-based self-selection into 7 layer-type groups with live size display. Random assignment for undecided members at timer expiry. Empty groups allowed (layer skipped).
- **Deliberation** — per-group audio preview + transparent majority voting + ambassador volunteering. Timer-based resolution. Forfeited layers when no ambassador volunteers.
- **Ambassador Ceremony** — fixed-order sequential lock-in at a physical altar. Accelerometer detection (Device Orientation API) for face-down phone placement. Immediate audio activation on lock-in.
- **Audio Preview System** — pre-rendered mp3 files per fragment, served statically, played in-browser during deliberation via HTML5 Audio API.
- **Altar Detection** — Device Orientation / Accelerometer API to detect face-down + still phone as the ceremony lock-in gesture. No external hardware required.
- **`assembly.ts`**, **`deliberation.ts`**, **`ceremony.ts`** conductor modules.
- **`useAudioPreview`** and **`useAltarDetection`** hooks.
- **`AssemblyCards`**, **`DeliberationBoard`**, **`AudioPreview`**, **`AmbassadorPrompt`**, **`CeremonyView`**, **`AltarReady`** components.
- **`finale_groups`**, **`finale_group_votes`**, **`ceremony_events`** DB tables.

### Changed Systems
- **Show phase state machine**: `finale_consensus` replaced by `finale_assembly` → `finale_deliberation` → `finale_ceremony` (three phases instead of one).
- **FinaleState type**: completely restructured — consensus game state replaced by assembly, deliberation, and ceremony state objects.
- **FinaleConfig**: consensus config (round duration, thresholds, decay) replaced by assembly/deliberation/ceremony config (timer durations, ceremony order, preview paths, layer labels).
- **Conductor commands/events**: all consensus-related commands/events removed; replaced with assembly, deliberation, and ceremony commands/events.
- **WebSocket events**: `consensus_vote` removed; `join_group`, `group_vote`, `volunteer_ambassador`, `altar_lock_in` added. `convergence_update` removed; `group_update`, `ambassador_called`, `altar_ready`, `altar_confirmed` added.
- **NPC system**: simplified from hybrid auto-trigger + manual to event-driven + manual. Messages are tied to phase transitions rather than per-round pattern matching.
- **Fragment type**: gains `previewAudioPath` field for audio preview support.
- **GainConfig**: `consensusSwellBeats` renamed to `ceremonySwellBeats`.
- **Environment variables**: consensus variables replaced with assembly/deliberation/ceremony variables.
- **Folder structure**: `consensus-game.ts` → `assembly.ts` + `deliberation.ts` + `ceremony.ts`. Component files renamed/replaced. New hooks added. `public/audio/previews/` directory added. `npc-triggers.json` → `npc-messages.json`.
