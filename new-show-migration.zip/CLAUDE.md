# CLAUDE.md — AI Agent Context

## What This Project Is
An interactive live performance system: a solo theatrical show where ~40 audience members help build songs in real time via their phones. Three story/song-building cycles, each with rising stakes (Doubt threshold), followed by a collaborative finale where the audience remixes fragments from all three songs.

## Key Architecture Decisions
- **Next.js + Custom Server + Socket.IO**: Single process, persistent WebSocket connections, all state in one place
- **Conductor pattern**: Pure state machine (no I/O) for all show logic. Server wraps it with WebSocket, persistence, and OSC.
- **Full state sync**: Broadcast complete (filtered) state on every mutation. No granular event patching on clients.
- **SQLite + WAL**: Persist every state change atomically. Recovery by reloading from DB.
- **Cloud-hosted server**: Audience connects via public URL. Ableton OSC bridge runs locally on performer's machine.
- **Binary choices**: All song-building votes are A/B. No multi-option voting.
- **Configurable safe parameters**: Stewardship parameter mappings are defined in config, not hardcoded.

## Read Order for New Agents
1. **This file** (you're here)
2. **ARCHITECTURE.md** — Full system spec, data models, state machine, protocols
3. **DECISIONS.md** — Open questions and resolved design decisions
4. **conductor/types.ts** — Shared type definitions (the system's vocabulary)
5. **CHANGELOG.md** — Recent changes with context and intent

## Common Tasks

### Adding a new layer type
1. Add to `LayerType` union in `conductor/types.ts`
2. Add color/symbol mapping in `lib/identity.ts`
3. Update `config/default-show.json` with new layer configs
4. No conductor logic changes needed (layer types are display-only)

### Changing doubt thresholds
1. Update `LayerConfig.doubtThreshold` values in `config/default-show.json`
2. Or use controller UI: `SET_THRESHOLD` command adjusts live

### Adding a new conductor command
1. Add to `ConductorCommand` union in `conductor/types.ts`
2. Add handler in `conductor/conductor.ts`
3. Add corresponding event(s) to `ConductorEvent` if needed
4. Add socket handler in `server/socket.ts`
5. Add controller UI button in `components/controller/`
6. Write test in `conductor/__tests__/`

### Modifying the finale scheduling algorithm
1. Logic lives in `conductor/finale.ts`
2. The scheduling function takes: queue, centroid weights, stewardship history
3. Returns: which queue entries to activate in which slots
4. Test thoroughly — fairness guarantees matter

## Testing
- **Conductor tests** (`conductor/__tests__/`): Pure logic, no mocking needed. These are the most important tests.
- **Server tests** (`server/__tests__/`): May need Socket.IO mocks.
- **Run without Ableton**: Set `OSC_ENABLED=false`. Timing engine uses JS timers. Audio cues are logged.

## What NOT to Do
- Don't add I/O to the Conductor (no fetch, no WebSocket, no DB calls)
- Don't split state across multiple sources — SQLite + in-memory is the single source
- Don't send audio meter data through state_sync (use dedicated high-frequency event)
- Don't hardcode musical content — everything goes through ShowConfig
- Don't assume a specific number of audience members — design for variable counts
- Don't invent solutions for open questions in DECISIONS.md without flagging them
